Payton Mock

To run the OS:

Click and drag the OS.jar file over the DropRun.bat file. The OS will start in the command prompt.